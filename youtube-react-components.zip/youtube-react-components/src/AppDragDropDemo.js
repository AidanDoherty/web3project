import React, { Component } from 'react';
import './App.css';

export default class AppDragDropDemo extends Component {
    state = {
        tasks: [
            {name:"Danny",category:"wip", bgcolor: "yellow"},
            {name:"Mike", category:"wip", bgcolor:"pink"},
            {name:"Aidan", category:"complete", bgcolor:"skyblue"},
             {name:"Joe", category:"test1", bgcolor:"skyblue"}
          ]
    }

    onDragStart = (ev, id) => {
        console.log('dragstart:',id);
        ev.dataTransfer.setData("id", id);
    }

    onDragOver = (ev) => {
        ev.preventDefault();
    }

    onDrop = (ev, cat) => {
       let id = ev.dataTransfer.getData("id");
       
       let tasks = this.state.tasks.filter((task) => {
           if (task.name == id) {
               task.category = cat;
           }
           return task;
       });

       this.setState({
           ...this.state,
           tasks
       });
    }

    render() {
        var tasks = {
            wip: [],
            complete: [],
            test1: [],
            test2: [],
            test3:[],
            test4: [],
            test5: [],
            test6: [],

        }

        this.state.tasks.forEach ((t) => {
            tasks[t.category].push(
                <div key={t.name} 
                    onDragStart = {(e) => this.onDragStart(e, t.name)}
                    draggable
                    className="draggable"
                    style = {{backgroundColor: t.bgcolor}}
                >
                    {t.name}
                </div>
            );
        });

        return (
            <div class="grid-container" >
            <div >
                <h2 className="header">DRAG & DROP DEMO</h2>
                <div className="grid-item"
                    onDragOver={(e)=>this.onDragOver(e)}
                    onDrop={(e)=>{this.onDrop(e, "wip")}}>
                    <span className="task-header"> </span>
                    {tasks.wip}
                </div>
                <div className="grid-item" 
                    onDragOver={(e)=>this.onDragOver(e)}
                    onDrop={(e)=>this.onDrop(e, "complete")}>
                     <span className="task-header"></span>
                     {tasks.complete}
                </div>
                <div className="grid-item" 
                    onDragOver={(e)=>this.onDragOver(e)}
                    onDrop={(e)=>this.onDrop(e, "test6")}>
                     <span className="task-header"></span>
                     {tasks.test6}
                </div>
                <div className="grid-item" 
                    onDragOver={(e)=>this.onDragOver(e)}
                    onDrop={(e)=>this.onDrop(e, "test5")}>
                     <span className="task-header"></span>
                     {tasks.test5}
                </div>
                <div className="grid-item" 
                    onDragOver={(e)=>this.onDragOver(e)}
                    onDrop={(e)=>this.onDrop(e, "test4")}>
                     <span className="task-header"></span>
                     {tasks.test4}
                </div>
                <div className="grid-item" 
                    onDragOver={(e)=>this.onDragOver(e)}
                    onDrop={(e)=>this.onDrop(e, "test3")}>
                     <span className="task-header"></span>
                     {tasks.test3}
                </div>
                <div className="grid-item" 
                    onDragOver={(e)=>this.onDragOver(e)}
                    onDrop={(e)=>this.onDrop(e, "test2")}>
                     <span className="task-header"></span>
                     {tasks.test2}
                </div>
                <div className="grid-item" 
                    onDragOver={(e)=>this.onDragOver(e)}
                    onDrop={(e)=>this.onDrop(e, "test1")}>
                     <span className="task-header"></span>
                     {tasks.test1}
                </div>
                <div className="grid-item" 
                    onDragOver={(e)=>this.onDragOver(e)}
                    onDrop={(e)=>this.onDrop(e, "test1")}>
                     <span className="task-header"></span>
                     {tasks.test1}
                </div>


            </div>
            </div>
        );
    }
}